import abi from './Transactions.json'

export const contractABI = abi.abi;
export const contractAddress = '0x98dFD0E717B3c6538807A4c366D169270feBE96D'

