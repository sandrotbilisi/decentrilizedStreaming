const Welcome = () => {
    const { value } = useContext(LiveStrimingContext);
    console.log(value)
}

export default Welcome;