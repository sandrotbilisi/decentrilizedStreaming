# threejs-project-template

* npm install

* npm run dev

* npm build


<img width="726" alt="image" src="https://user-images.githubusercontent.com/6615532/224009612-6f788fe6-1b04-4896-8ad1-1d61b9d0a24a.png">
